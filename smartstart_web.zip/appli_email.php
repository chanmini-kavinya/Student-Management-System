<!DOCTYPE html>
<html>
<head>
	<title>Email</title>
	<link rel="stylesheet" type="text/css" href="css/form.css"/>
</head>
<body>
<div class="banner">
	<h1>Send Email</h1><br>
</div>
	
<div class="item"><label for="subject">Subject</label>
<input type="text" id="subject" name="subject"  /></br>
	Message<br></div>
<div class="item"><textarea rows="10" cols="95" name="message">
</textarea><br></div>
 <div class="btn-block">
<input type="submit" value="Send" name="btnSend">
</div>
	<hr>
</body>
</html>