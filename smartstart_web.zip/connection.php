
	<?php

$host ="localhost";
	$uname = "id17192658_root";
	$pwd = 'Sy=T<-?%i3y4Ki*>';
	$db_name = "id17192658_studentdb";

        ?>
